// Author: Linyi Jiang
// Date: 2023-04-02
// LICENSE: free to use

#include "LargeNum.h"

// default: 0
LargeNum::LargeNum() {
    size = 1;
    memset(num, 0, sizeof(int)*MAXN);
}
// cast string to large number
LargeNum::LargeNum(string& s) {
    memset(num, 0, sizeof(int)*MAXN);
    size = s.length();
    for (int i = s.length() - 1; i >= 0; i--) {    // be careful of the order!
        num[i] = s[s.length() - i - 1] - '0';
    }
}
LargeNum::~LargeNum() {}


// to compare two large numbers
bool LargeNum::operator>=(LargeNum &l) {
    if (size > l.size) {
        return true;
    } else if (size < l.size) {
        return false;
    } else {
        for (int i = size - 1; i >= 0; i--) {
            if (num[i] < l.num[i]) {
                return false ;
            } else if (num[i] > l.num[i]) {
                return true;
            }
        }
        return true;
    }
}
// plus operand
LargeNum LargeNum::operator+(LargeNum &l) {
    LargeNum ans;
    int length = size >= l.size ? size : l.size;
    for (int i = 0; i < length; i++) {
        ans.num[i] = num[i] + l.num[i];
    }
    // carries
    for (int i = 0; i < length - 1; i++) {
        if (ans.num[i] >= 10) {
            ans.num[i+1]++;
            ans.num[i] -= 10;
        }
    }
    // end bit
    if (ans.num[length-1] >= 10) {
        ans.size = length + 1;
        ans.num[length] = 1;
        ans.num[length-1] -= 10;
    } else {
        ans.size = length;
    }
    return ans;
}

LargeNum LargeNum::operator-(LargeNum &l) {
    if (!(*this >= l)) {   // ensuring non-negative
        return l - *this;
    } else {
        LargeNum ans;
        int length = this->size;
        for (int i = 0; i < length; i++) {
            ans.num[i] = this->num[i] - l.num[i];
        }
        for (int i = 0; i < length; i++) {
            if (ans.num[i] < 0) {
                ans.num[i] += 10;
                ans.num[i+1]--;
            }
        }
        int a = 0;
        for (int i = length - 1; i >= 0; i--) {
            if (ans.num[i] != 0) {
                a = i;
                break;
            }
        }
        ans.size = a + 1;
        return ans;
    }
}
// multiply
LargeNum LargeNum::operator*(LargeNum &l) {
    LargeNum ans;
    ans.size = size + l.size - 1;
    for (int i = 0; i < size; i++)
        for (int j = 0; j < l.size; j++){
            ans.num[i+j] += num[i] * l.num[j];
            if (ans.num[i+j] >= 10) {
                ans.num[i+j+1] += ans.num[i+j] / 10;
                ans.num[i+j] %= 10;
            }
        }
    if (ans.num[ans.size] > 0) {
        ans.size++;
    }
    return ans;
}
// plus one number by ten with the multiplicity n
LargeNum LargeNum::mul(int n){
    LargeNum ans;
    for(int i = 0; i < size; i++)
        ans.num[i+n] = num[i];
    ans.size = size + n;
    return ans;
}
// divide
LargeNum LargeNum::operator/(LargeNum &l) {
    if (!(*this >= l)) {
        return l / *this;
    } else {
        LargeNum ans;
        LargeNum tmpBig, tmpSmall;
        tmpBig = *this;
        int coe = tmpBig.size - l.size;
        while (tmpBig >= l) {
            tmpSmall = l.mul(coe);
            while (tmpBig >= tmpSmall) {
                tmpBig = tmpBig - tmpSmall;
                ans.num[coe]++;
            }
            coe--;
        }
        for (int i = this->size; i >= 0; i--) {
            if (ans.num[i] != 0) {
                ans.size = i + 1;
                break;
            }
        }
        return ans;
    }
}
// mod
LargeNum LargeNum::operator%(LargeNum &l) {
    if (!(*this >= l) ) {
        return l % *this;
    } else {
        LargeNum tmp, ans;
        tmp = *this / l * l;
        ans = *this - tmp;
        return ans;
    }
}