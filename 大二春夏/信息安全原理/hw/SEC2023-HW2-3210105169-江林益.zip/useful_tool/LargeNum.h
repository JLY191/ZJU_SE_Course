// Author: Linyi Jiang
// Date: 2023-04-02
// LICENSE: free to use

#ifndef USEFUL_TOOL_LARGENUM_H
#define USEFUL_TOOL_LARGENUM_H

#define MAXN 1000       //1000 is enough for most cases
#include<iostream>
#include<string>
#include<vector>
#include<cstdlib>
#include<cstring>
using namespace std;

// core class, which implement operations, comparison(>=), and initialization

class LargeNum {
public:
    int num[MAXN];
    int size;        //size of the array

    LargeNum();
    LargeNum(string& s);
    ~LargeNum();

    bool operator>=(LargeNum &l);       // >= overloaded, compare from top to bottom
    friend ostream& operator<<(ostream &out, LargeNum l) {
        for (int i = l.size - 1; i >= 0; i--) {
            out << l.num[i];
        }
        return out;
    }

    LargeNum mul(int n);     // helper func for multiply

    //operations
    LargeNum operator+(LargeNum &l);
    LargeNum operator-(LargeNum &l);
    LargeNum operator*(LargeNum &l);
    LargeNum operator/(LargeNum &l);
    LargeNum operator%(LargeNum &l);
};





#endif //USEFUL_TOOL_LARGENUM_H
