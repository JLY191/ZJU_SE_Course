// Author: Linyi Jiang
// Date: 2023-04-02
// LICENSE: free to use

#include "LargeNum.h"
using namespace std;

int main() {
    // test algorithm
    cout << "First, let's test if the large numbers" << endl;
    cout << "can be handled properly." << endl;
    cout << "You are supposed to enter two large numbers." << endl;
    cout << "Please enter your first large number:" << endl;
    string s1,s2;
    cin >> s1;
    cout << "Next, please enter your second large number:" << endl;
    cin >> s2;
    LargeNum l1(s1),l2(s2);
    cout << "Basic calculation results are listed as followed, please check:" << endl;
    cout << "Num1 + Num2 = " << l1+l2 << endl;
    cout << "Num1 - Num2 = " << l1-l2 << endl;
    cout << "Num1 * Num2 = " << l1*l2 << endl;
    cout << "Num1 / Num2 = " << l1/l2 << endl;
    cout << "Num1 % Num2 = " << l1%l2 << endl;
    // keys
    cout << "Next, let's calculate keys." << endl;
    string s3, s4, s5, s6;
    cout << "Please enter p:" << endl;
    cin >> s3;
    LargeNum p(s3);
    cout << "Please enter g:" << endl;
    cin >> s4;
    LargeNum g(s4);
    cout << "Please enter A's private key:" << endl;
    cin >> s5;
    LargeNum aPrivate(s5);
    cout << "Please enter B's private key:" << endl;
    cin >> s6;
    LargeNum bPrivate(s6);
    LargeNum aPriTmp = aPrivate;
    string one("1");
    LargeNum One(one);
    LargeNum aPub = One, bPub = One, K = One;
    for (; aPrivate >= One; aPrivate = aPrivate - One) {
        aPub = aPub * g;
    }
    aPub = aPub % p;
    for (; bPrivate >= One; bPrivate = bPrivate - One) {
        bPub = bPub * g;
    }
    bPub = bPub % p;
    for (; aPriTmp >= One; aPriTmp = aPriTmp - One) {
        K = bPub * K;
    }
    K = K % p;
    cout << "A's public key is: " << aPub << endl;
    cout << "B's public key is: " << bPub << endl;
    cout << "The session key is: " << K << endl;
    // system("pause") for windows
    return 0;
}